<?php
/**
 * Displays footer site info
 *
 * @package NGO Organization
 * @subpackage ngo_organization
 */

?>
<div class="site-info">
	<div class="container">
		<p><?php ngo_organization_credit(); ?> <?php echo esc_html('By Themespride','ngo-organization'); ?> </p>
	</div>
</div>
